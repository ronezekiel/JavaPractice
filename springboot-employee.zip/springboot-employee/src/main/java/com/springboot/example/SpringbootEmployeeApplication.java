package com.springboot.example;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

import com.springboot.example.entity.Employee;
import com.springboot.example.entity.EmployeeResponse;

@SpringBootApplication
public class SpringbootEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootEmployeeApplication.class, args);

		String choiceMenu;

		RestTemplate restTemplate = new RestTemplate();

		Scanner inputScanner = new Scanner(System.in);

		do {
			System.out.println("[1] LOGIN\n[2] SIGNUP");
			String choiceLoginSignup = inputScanner.next();

			if (isNumeric(choiceLoginSignup)) {
				int choiceLoginSignupInt = Integer.parseInt(choiceLoginSignup);

				if (choiceLoginSignupInt == 1) {
					loginForm(inputScanner, restTemplate);

				} else if (choiceLoginSignupInt == 2) {
					signupForm(inputScanner, restTemplate);

				} else {
					System.out.println("INVALID INPUT");
				}
			} else {
				System.out.println("INVALID INPUT");
			}

			System.out.println("DO YOU WANT TO CONTINUE IN MENU? (Y/N)");
			choiceMenu = inputScanner.next();

		} while (choiceMenu.equalsIgnoreCase("Y"));

		System.exit(1);

	}

	public static void loginForm(Scanner inputScanner, RestTemplate restTemplate) {
		String choiceLogIn;

		do {
			System.out.print("EMPLOYEE ID: ");
			String loginEid = inputScanner.next();
			System.out.print("PASSWORD: ");
			String loginPassword = inputScanner.next();

			if (isCredentialCorrect(loginEid, loginPassword, restTemplate)) {
				System.out.println("HELLO!");
			} else {
				System.out.println("EID OR PASSWORD IS INCORRECT");
			}
			System.out.println("DO YOU WANT TO CONTINUE IN LOGIN? (Y/N)");
			choiceLogIn = inputScanner.next();

		} while (choiceLogIn.equalsIgnoreCase("Y"));

	}

	public static boolean isCredentialCorrect(String loginEid, String loginPassword, RestTemplate restTemplate) {

		final String fetchApi = "http://localhost:8080//api/employee/view";
		EmployeeResponse employeeResponse = restTemplate.getForObject(fetchApi, EmployeeResponse.class);

		for (Employee employee : employeeResponse.getEmployeeList()) {

			if (loginEid.equals(employee.getEid())) {
				if (loginPassword.equals(employee.getPassword())) {
					return true;
				}
			}
		}

		return false;

	}

	public static void signupForm(Scanner inputScanner, RestTemplate restTemplate) {

		String choiceSignUp;

		do {

			System.out.print("EMPLOYEE ID: ");
			String signupEid = inputScanner.next();

			if (isEmployeeExist(signupEid, restTemplate)) {

				System.out.println("EMPLOYEE ID IS ALREADY EXIST");

			} else {
				System.out.print("PASSWORD: ");
				String signupPassword = inputScanner.next();
				System.out.print("CONFIRM PASSWORD: ");
				String signupConfirmPassword = inputScanner.next();

				if (isPasswordMatch(signupPassword, signupConfirmPassword)) {
					System.out.print("FIRST NAME: ");
					String signupFirstName = inputScanner.next();
					System.out.print("LAST NAME: ");
					String signupLastName = inputScanner.next();
					System.out.print("EMAIl: ");
					String signupEmail = inputScanner.next();
					System.out.print("CONTACT NUMBER: ");
					String signupContactNumber = inputScanner.next();

					signUpEmployee(signupContactNumber, signupEid, signupPassword, signupFirstName, signupLastName,
							signupEmail, restTemplate);

				} else {
					System.out.println("PASSWORD AND CONFIRM PASSWORD DIDN'T MATCH");
				}

			}

			System.out.println("DO YOU WANT TO CONTINUE IN SIGNUP? (Y/N)");
			choiceSignUp = inputScanner.next();

		} while (choiceSignUp.equalsIgnoreCase("Y"));

	}

	public static boolean isEmployeeExist(String signupEid, RestTemplate restTemplate) {

		final String fetchApi = "http://localhost:8080//api/employee/view";
		EmployeeResponse employeeResponse = restTemplate.getForObject(fetchApi, EmployeeResponse.class);

		for (Employee employee : employeeResponse.getEmployeeList()) {
			if (signupEid.equals(employee.getEid())) {
				return true;
			}
		}
		return false;

	}

	public static boolean isPasswordMatch(String signupPassword, String signupConfirmPassword) {

		if (signupPassword.equals(signupConfirmPassword)) {
			return true;
		}
		return false;
	}

	public static void signUpEmployee(String signupContactNumber, String signupEid, String signupPassword,
			String signupFirstName, String signupLastName, String signupEmail, RestTemplate restTemplate) {
		int signupContactNumberInt = Integer.parseInt(signupContactNumber);

		final String registerApi = "http://localhost:8080//api/employee/signup";
		Employee employee = new Employee();
		employee.setEid(signupEid);
		employee.setPassword(signupPassword);
		employee.setFirstName(signupFirstName);
		employee.setLastName(signupLastName);
		employee.setEmail(signupEmail);
		employee.setContactNumber(signupContactNumberInt);
		Employee employee2 = restTemplate.postForObject(registerApi, employee, Employee.class);
		System.out.println("SIGN UP SUCCESSFULLY!");

	}

	public static boolean isNumeric(String string) {
		int intValue;

		if (string == null || string.equals("")) {

			return false;
		}

		try {
			intValue = Integer.parseInt(string);
			return true;

		} catch (NumberFormatException e) {
		}
		return false;
	}

}
