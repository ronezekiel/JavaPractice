package com.springboot.example.controller;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.springboot.example.entity.Employee;
import com.springboot.example.entity.EmployeeResponse;
import com.springboot.example.repository.EmployeeRepository;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {

	@Autowired
	EmployeeRepository employeeRepository;

	@PostMapping("/signup")
	public Employee createEmployee(@RequestBody Employee employee) {

		try {
			Employee saveEmployee = employeeRepository.save(employee);
			return saveEmployee;

		} catch (Exception e) {

			System.out.println("Error: " + e);
			return null;
		}

	}

	@GetMapping("/login")
	public String loginForm () {
		
		
		
		String HtmlResponse = "<!DOCTYPE html>\n" + "<html>\n" + "<head>\n" + "<meta charset=\"utf-8\">\n"
				+ "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
				+ "<title>Login</title>\n" + "\n" + "</head>\n" + "<script type=\"text/javascript\">\n"
				+ "	function myFunction() {\n" + "		var x = document.getElementById(\"password\");\n"
				+ "		if (x.type === \"password\") {\n" + "			x.type = \"text\";\n" + "		} else {\n"
				+ "			x.type = \"password\";\n" + "		}\n" + "	}\n" + "</script>\n" + "<body>\n" + "\n"
				+ "	<div class=\"box\">\n" + "\n" + "		<form action=\"http://localhost:8080//api/employee/viewHTML\" method=\"post\">\n"
				+ "			<span class=\"text-center\">Login Form</span>\n"
				+ "			<div class=\"input-container\">\n"
				+ "				<input type=\"text\" name=\"userName\" required=\"\"> <label>Username</label>\n"
				+ "			</div>\n" + "			<div class=\"input-container\">\n"
				+ "				<input type=\"password\" name=\"password\" id=\"password\" required=\"\">\n"
				+ "				<label>Password</label>\n" + "			</div>\n"
				+ "			<input type=\"checkbox\" onclick=\"myFunction()\">Show Password <br>\n"
				+ "			<input type=\"submit\" name=\"submit\" value=\"LOGIN\" class=\"btn\">\n"
				+ "		</form>\n" + "\n" + "		<br>\n" + "		<p>\n"
				+ "			Not a member? <a href=\"register.html\">Signup now</a>\n" + "		</p>\n" + "\n"
				+ "	</div>\n" + "\n" + "\n" + "\n" + "\n" + "	<style type=\"text/css\">\n" + "body {\n"
				+ "	background-image: linear-gradient(to right, #000428, #004e92);\n" + "	padding-top: 200px;\n"
				+ "	font-family: 'Noto Sans', sans-serif;\n" + "}\n" + "\n" + ".text-center {\n" + "	color: #000;\n"
				+ "	text-transform: uppercase;\n" + "	font-size: 23px;\n" + "	margin: -50px 0 80px 0;\n"
				+ "	display: block;\n" + "	text-align: center;\n" + "}\n" + "\n" + "small {\n" + "	color: #777;\n"
				+ "	font-size: 12px;\n" + "}\n" + "\n" + ".box {\n" + "	position: absolute;\n" + "	left: 50%;\n"
				+ "	top: 50%;\n" + "	transform: translate(-50%, -50%);\n" + "	background-color: #fff;\n"
				+ "	border-radius: 3px;\n" + "	padding: 70px 100px;\n" + "	padding-top: 100px;\n" + "}\n" + "\n"
				+ ".input-container {\n" + "	position: relative;\n" + "	margin-bottom: 25px;\n" + "}\n" + "\n"
				+ ".input-container label {\n" + "	position: absolute;\n" + "	top: 0px;\n" + "	left: 0px;\n"
				+ "	font-size: 16px;\n" + "	color: #000;\n" + "	pointer-event: none;\n"
				+ "	transition: all 0.5s ease-in-out;\n" + "}\n" + "\n" + ".input-container input {\n"
				+ "	border: 0;\n" + "	border-bottom: 1px solid #555;\n" + "	background: transparent;\n"
				+ "	width: 100%;\n" + "	padding: 8px 0 5px 0;\n" + "	font-size: 16px;\n" + "	color: #000;\n" + "}\n"
				+ "\n" + ".input-container input:focus {\n" + "	border: none;\n" + "	outline: none;\n"
				+ "	border-bottom: 1px solid #e74c3c;\n" + "}\n" + "\n" + ".btn {\n" + "	color: #fff;\n"
				+ "	background-color: #004e92;\n" + "	outline: none;\n" + "	border: 0;\n" + "	color: #fff;\n"
				+ "	padding: 10px 20px;\n" + "	text-transform: uppercase;\n" + "	margin-top: 50px;\n"
				+ "	border-radius: 2px;\n" + "	cursor: pointer;\n" + "	position: relative;\n" + "}\n"
				+ "/*.btn:after{\n" + "  content:\"\";\n" + "  position:absolute;\n"
				+ "  background:rgba(0,0,0,0.50);\n" + "  top:0;\n" + "  right:0;\n" + "  width:100%;\n"
				+ "  height:100%;\n" + "}*/\n"
				+ ".input-container input:focus ~ label, .input-container input:valid ~\n" + "	label {\n"
				+ "	top: -12px;\n" + "	font-size: 12px;\n" + "	color: #777;\n" + "}\n" + "</style>\n" + "</body>\n"
				+ "</html>";

		return HtmlResponse;

	}
	
	public static void loginForm(Scanner inputScanner, RestTemplate restTemplate) {
		String choiceLogIn;

		do {
			System.out.print("EMPLOYEE ID: ");
			String loginEid = inputScanner.next();
			System.out.print("PASSWORD: ");
			String loginPassword = inputScanner.next();

			if (isCredentialCorrect(loginEid, loginPassword, restTemplate)) {
				System.out.println("HELLO!");
			} else {
				System.out.println("EID OR PASSWORD IS INCORRECT");
			}
			System.out.println("DO YOU WANT TO CONTINUE IN LOGIN? (Y/N)");
			choiceLogIn = inputScanner.next();

		} while (choiceLogIn.equalsIgnoreCase("Y"));

	}

	public static boolean isCredentialCorrect(String loginEid, String loginPassword, RestTemplate restTemplate) {

		final String fetchApi = "http://localhost:8080//api/employee/view";
		EmployeeResponse employeeResponse = restTemplate.getForObject(fetchApi, EmployeeResponse.class);

		for (Employee employee : employeeResponse.getEmployeeList()) {

			if (loginEid.equals(employee.getEid())) {
				if (loginPassword.equals(employee.getPassword())) {
					return true;
				}
			}
		}

		return false;

	}

	@GetMapping("/view")
	public EmployeeResponse getEmployeeResponse() {

		List<Employee> employeeList = employeeRepository.findAll();
		EmployeeResponse employeeResponse = new EmployeeResponse();
		employeeResponse.setEmployeeList(employeeList);
		return employeeResponse;

	}

	@GetMapping("/viewHTML")
	public String viewHTML() {
		final String fetchApi = "http://localhost:8080//api/employee/view";
		RestTemplate restTemplate = new RestTemplate();
		EmployeeResponse employeeResponse = restTemplate.getForObject(fetchApi, EmployeeResponse.class);

		String htmlRespone = "<html>";
		htmlRespone += "<head>";
		htmlRespone += "<title>User Information</title>";
		htmlRespone += "<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>";
		htmlRespone += "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>";
		htmlRespone += "<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js'></script>";
		htmlRespone += "<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'></script>";
		htmlRespone += "</head>";
		htmlRespone += "<body>";
		htmlRespone += "<div class='messagebox'>";
		htmlRespone += "<h1 style='font-family: monospace;'>Employee Informations</h1>";
		htmlRespone += "<table class='table table-dark table-striped'>";
		htmlRespone += "<tr>";
		htmlRespone += "<th>Employee Id</th>";
		htmlRespone += "<th>First Name</th>";
		htmlRespone += "<th>Last Name</th>";
		htmlRespone += "<th>Email</th>";
		htmlRespone += "<th>Contact Number</th>";
		htmlRespone += "</tr>";
		htmlRespone += "";

		for (Employee employee : employeeResponse.getEmployeeList()) {
			String eid = employee.getEid();
			String empFirstName = employee.getFirstName();
			String empLastName = employee.getLastName();
			String empEmail = employee.getEmail();
			String empContactNumber = String.valueOf(employee.getContactNumber());

			htmlRespone += "<td>" + eid + "</td>";
			htmlRespone += "<td>" + empFirstName + "</td>";
			htmlRespone += "<td>" + empLastName + "</td>";
			htmlRespone += "<td>" + empEmail + "</td>";
			htmlRespone += "<td>" + empContactNumber + "</td>";
			htmlRespone += "</tr>";
		}

		htmlRespone += "</table>";
		htmlRespone += "<a href='login.html'>Logout</a></div>";
		htmlRespone += "</div>";
		htmlRespone += "<style type='text/css'>";
		htmlRespone += "body{background-image: linear-gradient(to right, #000428,#004e92);padding-top: 200px;}";
		htmlRespone += ".messagebox{margin: auto; width: 50%; padding: 10px; text-align: center;background-color: #ffffff;}";
		htmlRespone += "h2{font-family: monospace;}</style>";
		htmlRespone += "</body>";
		htmlRespone += "</html>";

		return htmlRespone;

	}

}
