package com.springboot.example.service;

import com.springboot.example.model.Employee;

public interface EmployeeService {

	Employee saveEmployee(Employee employee);
	
	
}
